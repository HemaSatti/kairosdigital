import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-customer-experience',
  templateUrl: './customer-experience.component.html',
  styleUrls: ['./customer-experience.component.css']
})
export class CustomerExperienceComponent implements OnInit {

 Url = 'assets/Industries.json';
 config:any;
 configResult:any;
 industryResult:any;
 checked = false;
 valCheck = false;
 optVal : string = '';

 constructor(private http:HttpClient) {}

  sample: FormGroup = new FormGroup({

    industry:new FormControl('', Validators.required),
    dataValue:new FormControl('', Validators.required),
    dataValue1:new FormControl('', Validators.required),
    dataValue2:new FormControl('', Validators.required),
    optVal:new FormControl('',Validators.required),
    checked:new FormControl('',Validators.required),
    checkValue:new FormControl('',Validators.required),
    valueCheck:new FormControl('',Validators.required),
    valCheck:new FormControl('',Validators.required),

  })

  showConfig() {
   let obs =  this.http.get(this.Url)
     obs.subscribe((industryResult:any)=>{
        this.config = industryResult.Industries;
        this.suggest('');
     });
    console.log(this.config);
  }

  suggest(Industry){
    this.configResult = this.config.filter(hema => hema.Industry.toLowerCase().startsWith(Industry.toLowerCase())).slice(0, 1000)
 }
  suggestVal(data){
    this.configResult = this.config.filter(hema => hema.Industry.toLowerCase().startsWith(data.toLowerCase())).slice(0, 1000)
    this.optVal=data
    console.log('hhhhhhhhhh', this.optVal)
  }

  checkIndus(){
   if(this.optVal==='other')
     return true;
   else
     return false;
  }

  ngOnInit() {

   this.showConfig()

  }

}
