import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import {Router} from '@angular/router';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {

  registerForm: FormGroup;
  device: string = '';
  deskDevice: string;
  greet: string;

  constructor(private formBuilder: FormBuilder, private router:Router) {

    var hrs = new Date().getHours();
    var isMobile = /iPhone|Android/i.test(navigator.userAgent);
    var isTab = /iPad|iPod|Tablet/i.test(navigator.userAgent);


    if (isMobile) {
      this.device = 'Mobile'
      console.log("You are using Mobile", this.device);
    } else if (isTab) {
      this.device = 'Tablet'
      console.log("You are using Tab", this.device);
    }else {
      this.device = 'Desktop'
      console.log("You are using Desktop", this.device);
    }

    if (hrs < 12)
      this.greet = 'Good Morning';
    else if (hrs >= 12 && hrs < 16)
      this.greet = 'Good Afternoon';
    else if (hrs >= 16 && hrs <= 24)
      this.greet = 'Good Evening';

  }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      name: ['', [Validators.required, Validators.minLength(4), Validators.pattern(/^[a-zA-Z\s]*$/)]],
      designation: ['', [Validators.required, Validators.minLength(3), Validators.pattern(/^[A-Za-z.\s_-]+$/)]],
      email: ['', [Validators.required, Validators.email, Validators.pattern(/^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(?!hotmail|gmail|yahoo)(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/)]],
      company: ['', [Validators.required, Validators.pattern(/^[0-9A-Za-z'-.]+(?:\s[0-9A-Za-z'-]+)*$/)]]
    });
  }

  onSubmit() {

    alert('the form submitted successfully');
    this.router.navigate(['/customer']);
    // console.log( 'hemaaaaaaaa',this.registerForm.value);
    // console.log('lakshmi',this.registerForm.value.email);
  }

}
